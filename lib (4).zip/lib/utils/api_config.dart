class ApiConfig {
  static const String baseUrl =
      'https://notes-api-production-7439.up.railway.app';
}
