class ApiConfig {
  static const String baseUrl = 'https://TU-DOMINIO-RAILWAY';
}